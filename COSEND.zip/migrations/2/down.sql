
DROP INDEX idx_admin_sessions_token;
DROP INDEX idx_tracking_updates_parcel;
DROP INDEX idx_chat_messages_recipient;
DROP INDEX idx_chat_messages_conversation;
DROP INDEX idx_activity_logs_created;
DROP INDEX idx_activity_logs_user;
DROP INDEX idx_activity_logs_entity;
DROP TABLE admin_sessions;
DROP TABLE tracking_updates;
DROP TABLE chat_messages;
DROP TABLE activity_logs;
DROP TABLE admin_users;
