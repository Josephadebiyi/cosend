
DROP INDEX idx_transactions_parcel;
DROP INDEX idx_parcels_trip;
DROP INDEX idx_parcels_sender;
DROP INDEX idx_trips_route;
DROP INDEX idx_trips_traveler;
DROP INDEX idx_users_email;
DROP TABLE transactions;
DROP TABLE parcels;
DROP TABLE trips;
DROP TABLE users;
